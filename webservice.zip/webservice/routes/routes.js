const userRoutes = require('./users');

const appRouter = (app, fs) => {
    app.get('/', (req, res) => {
        res.send('NODEJS - Test Server Uni-FACEF');
    });

    userRoutes(app, fs);
};
module.exports = appRouter;

